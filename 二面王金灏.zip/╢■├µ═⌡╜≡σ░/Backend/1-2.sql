--建表
CREATE TABLE STUDENTS
(
	id SERIAL PRIMARY KEY NOT NULL,
	name VARCHAR(50) NOT NULL,
	age INT NOT NULL,
	gender INT NOT NULL,
	current_class VARCHAR(255) NOT NULL,
	freshman_class VARCHAR(255),
	zju_id BIGINT UNIQUE NOT NULL
);
--写入三条信息,1男0女
INSERT INTO STUDENTS
(id,name,age,gender,current_class,freshman_class,zju_id)
VALUES
(1,'小张',20,0,'计科1901','工信1918',3190101234);

INSERT INTO STUDENTS
(id,name,age,gender,current_class,zju_id)
VALUES
(2,'小胡',19,1,'工信2017',3200105678);

INSERT INTO STUDENTS
(id,name,age,gender,current_class,freshman_class,zju_id)
VALUES
(3,'小王',21,0,'机械1802','机材1801',3180109012);