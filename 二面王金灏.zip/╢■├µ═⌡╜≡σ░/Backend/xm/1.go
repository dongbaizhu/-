package main

import (
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"fmt"
)
type Student struct {
	ID            uint
	Name          string
	Age           int
	Gender        int
	CurrentClass  string
	FreshmanClass string
	ZjuId         int64
}
func main(){
	//连接到qsc数据库
	dsn:="host=localhost user=postgres password=wjhyyds0713 dbname=qsc port=5432 sslmode=disable TimeZone=Asia/Shanghai"
	db,err:=gorm.Open(postgres.Open(dsn),&gorm.Config{})
	if err != nil {
        panic("数据库连接失败，请检查参数")
    }
	//添加记录实验
	db.Create(&Student{ID:4,Name:"小王2号",Age:18,Gender:1,CurrentClass:"工信2033",ZjuId:3200105115})
	//查询实验1
	stu1 := Student{} 
	db.Where(&Student{Name: "小张"}).First(&stu1)
	fmt.Println(stu1.ZjuId)
	//查询实验2
	stu:=[]Student{}
	db.Where(&Student{}).Find(&stu)
	for i:=0;i<4;i++ {
		if stu[i].Age>19 {
			fmt.Println(stu[i].Name)
		}
	}
	//查询删除实验
	stu2 := Student{} 
	db.First(&stu2,4)
	fmt.Println(stu2)
	db.Delete(&stu2, 4)
}
